public class MyException2 extends Exception{
		   public MyException2() {//Constructor
      
   }
   public MyException2(String str){
		super(str);
			}
				
}
