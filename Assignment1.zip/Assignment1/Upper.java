import java.util.*;
import java.io.File;

public class Upper{
			public StringBuilder Converter(String a,String b)
			{
							
						
				int i=0;
				
				StringBuilder a1=new StringBuilder(b);
				System.out.println("A is "+a);	
				System.out.println("a1 is "+a1);
int j=(int)a.charAt(0)-32;
				try{
				if(j>=65 && j<=90)
				{
				while(i<a1.length()-1)
				{
				
				if(a1.charAt(i)==(a.charAt(0)) )
				{			
									
			
char k=(char)j;
a1.setCharAt(i,k);	
	i++;			
					}
					i++;
				}
				}
				else{
					MyException3 m2=new MyException3("Exception Occurs\n");	
					throw m2;
					}
				}	
			catch(MyException3 e1){
					System.out.println("Invalid letter ,Allowed only capital letters");}				
				return a1;
				}
					}
