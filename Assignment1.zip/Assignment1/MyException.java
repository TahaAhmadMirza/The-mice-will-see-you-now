public class MyException extends Exception {
   
   public MyException() {//Constructor
      
   }
   public MyException(String str){
		super(str);
			}

   
}


