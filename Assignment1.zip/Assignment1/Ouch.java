import java.util.*;
import java.io.File;
public class Ouch{


		public StringBuffer function(StringBuffer a,String b,String c,int i)
		{
		try{
			if(i>=a.length())
			{
			return a;
				}
			else
			{
			if(a.charAt(i)==c.charAt(0))
			{
				while(a.charAt(i)!=' ')
				{
					i+=1;
					}
				a.insert(i,b);
				i+=b.length();
				return function(a,b,c,i+1);	
				
				}
			else{
				return function(a,b,c,i+1);
				}
				}
			}
		catch(StringIndexOutOfBoundsException e)
		{
			System.out.println("String Index Out of Bounds Exception has been Occured");
				}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array Index Out of Bounds Exception has bee Occurred");
				}
		
return a;}


		public StringBuffer ouch(String a ,String b,String c)
		{
		int i=0;
		StringBuffer f=new StringBuffer(a);			
				f=function(f,b,c,i);
					return f;}
			}
