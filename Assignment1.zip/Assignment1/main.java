import java.util.StringTokenizer;  
import java.util.*;

public class main{
	public static void main(String args[])throws Exception
		{
		
	try{
			String s=args[0];
			String str="";
			
			
		try{
			for(int i=1;i<args.length;i++)
			{
				if(i!=0)
					str+=args[i];
				else 
					str+=" "+args[i];
			}

							
			if(s.startsWith("-"))
			{
				s=args[0].substring(1);
				if(s.startsWith("u"))
				{
					s=s.substring(1);
					
					System.out.println(s);
					Upper l=new Upper();
					int i=1;
					String str1="";
					while(i<args.length)
					{
						str1+=args[i]+" ";
						i++;						
							}
					System.out.println(str1+"1");
										
					System.out.println(l.Converter(s,str1));							
				}
				else if(s.startsWith("o"))
				{
					s=args[0]+args[1];
					str="";
					for(int i=2 ;i<args.length;i++)
					{
						
							str+=args[i]+" ";
					}
					
					String ch = s.substring(2,s.length()-(s.length()-3));
					s=s.substring(3,s.length());

					System.out.println("Str is "+ str);	
					System.out.println("S is"+ s);
					System.out.println("Ch is "+ch);	

					Ouch o=new Ouch();
					s=" "+s;
					System.out.println(o.ouch(str,s,ch));
					
				}
				else
				{
					MyException2 m=new MyException2(" Instead of u or o has been written");
					throw m;}
					

	
			}
			else
				{
					MyException m1=new MyException(s+" Instead of - has been written");
					throw m1;
							}
				
			}
		
		catch(MyException2 e1){
			System.out.print("Here is the exception "+e1);
				}
		catch(NullPointerException e)
		{
		System.out.println("Null Pointer Exception has been occured");
			}
		catch(MyException e)
		{
		e.printStackTrace();
		System.out.println("Here is the exception "+e);
				}

}
catch (ArrayIndexOutOfBoundsException e3)
		{
			System.out.println("You have exceeded the size of an array\n");
				}
}
	
}			



