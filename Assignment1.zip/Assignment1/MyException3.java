public class MyException3 extends Exception {
   
   public MyException3() {//Constructor
      
   }
   public MyException3(String str){
		super(str);
			}

   
}

